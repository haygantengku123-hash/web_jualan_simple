<?php
session_start();
include 'includes/koneksi.php';

$error = '';
$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validasi input
    if (empty($username) || empty($password) || empty($confirm_password)) {
        $error = "Semua kolom harus diisi.";
    } elseif ($password !== $confirm_password) {
        $error = "Konfirmasi password tidak cocok.";
    } elseif (strlen($password) < 8) {
        $error = "Password harus memiliki minimal 8 karakter.";
    } else {
        // Cek apakah username sudah ada di database
        $sql_check_user = "SELECT id FROM users WHERE username = ?";
        $stmt_check_user = $conn->prepare($sql_check_user);
        
        // Pengecekan error pada prepare()
        if ($stmt_check_user === false) {
            $error = "Gagal mempersiapkan query: " . $conn->error;
        } else {
            $stmt_check_user->bind_param("s", $username);
            $stmt_check_user->execute();
            $stmt_check_user->store_result();
            
            if ($stmt_check_user->num_rows > 0) {
                $error = "Username sudah terdaftar. Silakan pilih username lain.";
            } else {
                // Hash password untuk keamanan sebelum disimpan
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // Masukkan data pengguna baru ke database
                $sql_insert = "INSERT INTO users (username, password, role, balance) VALUES (?, ?, 'customer', 0.00)";
                $stmt_insert = $conn->prepare($sql_insert);
                
                // Pengecekan error pada prepare()
                if ($stmt_insert === false) {
                    $error = "Gagal mempersiapkan query: " . $conn->error;
                } else {
                    $stmt_insert->bind_param("ss", $username, $hashed_password);

                    if ($stmt_insert->execute()) {
                        $_SESSION['message'] = "Pendaftaran berhasil! Silakan login.";
                        header("Location: login.php");
                        exit();
                    } else {
                        $error = "Gagal mendaftar. Silakan coba lagi.";
                    }
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - Web Jualan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <div class="card p-4 shadow" style="max-width: 400px; width: 100%;">
            <h2 class="text-center mb-4">Daftar Akun Baru</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger" role="alert"><?= $error; ?></div>
            <?php endif; ?>

            <form action="register.php" method="post">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Konfirmasi Password</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                </div>
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Daftar</button>
                </div>
            </form>
            <p class="text-center mt-3">
                Sudah punya akun? <a href="login.php">Login di sini</a>
            </p>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>