<?php
session_start();
include '../includes/koneksi.php'; // PASTIKAN BARIS INI BENAR

// Cek jika pengguna belum login atau bukan admin, arahkan ke halaman login
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Ambil semua data produk dari database
$sql = "SELECT * FROM products ORDER BY created_at DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Produk - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Manajemen Produk - Admin</h1>
        <p>
              <a href="../index.php" class="btn btn-primary">Kembali Ke Halaman Utama</a> 
              <a href="deposits.php" class ="btn btn-primary"> Managemen Deposit</a>
              <a href="add_product.php" class="btn btn-primary">Tambah Produk Baru</a>
              <a href="../logout.php" class="btn btn-primary">Logout</a>
              
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success mt-3" role="alert"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger mt-3" role="alert"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-striped table-hover mt-4">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Gambar</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Tanggal Dibuat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['id']); ?></td>
                                <td>
                                    <?php if ($row['image']): ?>
                                        <img src="../<?= htmlspecialchars($row['image']); ?>" alt="Gambar Produk" style="max-width: 80px; height: auto;">
                                    <?php else: ?>
                                        Tidak ada gambar
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($row['name']); ?></td>
                                <td>Rp<?= number_format($row['price'], 0, ',', '.'); ?></td>
                                <td><?= htmlspecialchars($row['stock']); ?></td>
                                <td><?= date('d-m-Y', strtotime($row['created_at'])); ?></td>
                                <td>
                                    <a href="edit_product.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm me-2">Edit</a>
                                    <a href="#" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteModal<?= $row['id']; ?>">Hapus</a>
                                </td>
                            </tr>

                            <div class="modal fade" id="deleteModal<?= $row['id']; ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?= $row['id']; ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="deleteModalLabel<?= $row['id']; ?>">Konfirmasi Hapus</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            Apakah Anda yakin ingin menghapus produk **"<?= htmlspecialchars($row['name']); ?>"**?
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                            <a href="delete_product.php?id=<?= $row['id']; ?>" class="btn btn-danger">Hapus</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center">Belum ada produk yang ditambahkan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>