<?php
session_start();
include '../includes/koneksi.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$product_id = $_GET['id'];

$sql = "DELETE FROM products WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $product_id);

if ($stmt->execute()) {
    $_SESSION['message'] = "Produk berhasil dihapus.";
} else {
    $_SESSION['error'] = "Gagal menghapus produk: " . $conn->error;
}

header("Location: index.php");
exit();
?>