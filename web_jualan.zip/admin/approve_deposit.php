<?php
session_start();
include '../includes/koneksi.php';

// Cek hak akses admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id'])) {
    $_SESSION['error'] = "ID deposit tidak valid.";
    header("Location: deposits.php");
    exit();
}

$deposit_id = $_GET['id'];

// Mulai transaksi
$conn->begin_transaction();

try {
    // 1. Ambil data deposit yang pending
    $sql_deposit = "SELECT user_id, amount FROM deposits WHERE id = ? AND status = 'pending' FOR UPDATE";
    $stmt_deposit = $conn->prepare($sql_deposit);
    $stmt_deposit->bind_param("i", $deposit_id);
    $stmt_deposit->execute();
    $result_deposit = $stmt_deposit->get_result();
    $deposit = $result_deposit->fetch_assoc();

    if (!$deposit) {
        throw new Exception("Permintaan deposit tidak ditemukan atau sudah diproses.");
    }
    
    // 2. Tambahkan saldo ke akun pengguna
    $user_id = $deposit['user_id'];
    $amount = $deposit['amount'];

    $sql_update_balance = "UPDATE users SET balance = balance + ? WHERE id = ?";
    $stmt_update_balance = $conn->prepare($sql_update_balance);
    $stmt_update_balance->bind_param("di", $amount, $user_id);
    $stmt_update_balance->execute();

    // 3. Perbarui status deposit menjadi 'approved'
    $sql_update_status = "UPDATE deposits SET status = 'approved' WHERE id = ?";
    $stmt_update_status = $conn->prepare($sql_update_status);
    $stmt_update_status->bind_param("i", $deposit_id);
    $stmt_update_status->execute();
    
    // Jika semua berhasil, commit transaksi
    $conn->commit();
    $_SESSION['message'] = "Deposit berhasil disetujui.";
    
} catch (Exception $e) {
    // Jika ada error, rollback transaksi
    $conn->rollback();
    $_SESSION['error'] = "Gagal menyetujui deposit: " . $e->getMessage();
}

// Arahkan kembali ke halaman manajemen deposit
header("Location: deposits.php");
exit();
?>