<?php
session_start();
include '../includes/koneksi.php';

// Pastikan pengguna sudah login dan memiliki peran 'admin'
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Cek apakah ada ID produk yang dikirimkan
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: products.php");
    exit();
}

$product_id = $_GET['id'];

// Ambil data produk dari database
$sql = "SELECT * FROM products WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: products.php");
    exit();
}
$product = $result->fetch_assoc();

// Menangani permintaan POST untuk pembaruan produk
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $current_image = $_POST['current_image'];

    // Validasi data
    if (empty($name) || empty($description) || empty($price) || empty($stock)) {
        $_SESSION['error'] = "Semua kolom harus diisi.";
        header("Location: edit_product.php?id=" . $product_id);
        exit();
    }
    
    // Validasi harga dan stok
    if (!is_numeric($price) || !is_numeric($stock) || $price < 0 || $stock < 0) {
        $_SESSION['error'] = "Harga dan stok harus berupa angka positif.";
        header("Location: edit_product.php?id=" . $product_id);
        exit();
    }

    $image_path = $current_image;

    // Menangani upload gambar baru
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $target_dir = "../uploads/";
        $image_name = basename($_FILES["image"]["name"]);
        $image_ext = strtolower(pathinfo($image_name, PATHINFO_EXTENSION));
        $new_image_name = uniqid('product_', true) . '.' . $image_ext;
        $target_file = $target_dir . $new_image_name;
        
        // Cek tipe file
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array($image_ext, $allowed_ext)) {
            $_SESSION['error'] = "Maaf, hanya file JPG, JPEG, PNG & GIF yang diperbolehkan.";
            header("Location: edit_product.php?id=" . $product_id);
            exit();
        }

        // Pindahkan file yang diunggah
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            // Hapus gambar lama jika ada
            if ($current_image && file_exists("../" . $current_image)) {
                unlink("../" . $current_image);
            }
            $image_path = "uploads/" . $new_image_name;
        } else {
            $_SESSION['error'] = "Gagal mengunggah gambar baru.";
            header("Location: edit_product.php?id=" . $product_id);
            exit();
        }
    }

    // Perbarui data produk di database
    $sql_update = "UPDATE products SET name = ?, description = ?, price = ?, stock = ?, image = ? WHERE id = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("ssiisi", $name, $description, $price, $stock, $image_path, $product_id);

    if ($stmt_update->execute()) {
        $_SESSION['message'] = "Produk berhasil diperbarui.";
        header("Location: products.php");
        exit();
    } else {
        $_SESSION['error'] = "Gagal memperbarui produk: " . $conn->error;
        header("Location: edit_product.php?id=" . $product_id);
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Edit Produk</h1>
        <p><a href="products.php" class="btn btn-secondary">Kembali ke Daftar Produk</a></p>

        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success mt-3" role="alert"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger mt-3" role="alert"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <form action="edit_product.php?id=<?= $product_id; ?>" method="post" enctype="multipart/form-data">
            <input type="hidden" name="current_image" value="<?= htmlspecialchars($product['image']); ?>">
            <div class="mb-3">
                <label for="name" class="form-label">Nama Produk</label>
                <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($product['name']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Deskripsi</label>
                <textarea class="form-control" id="description" name="description" rows="3" required><?= htmlspecialchars($product['description']); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Harga</label>
                <input type="number" class="form-control" id="price" name="price" value="<?= htmlspecialchars($product['price']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="stock" class="form-label">Stok</label>
                <input type="number" class="form-control" id="stock" name="stock" value="<?= htmlspecialchars($product['stock']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Gambar Produk</label>
                <input type="file" class="form-control" id="image" name="image">
                <?php if ($product['image']): ?>
                    <small class="form-text text-muted mt-2">Gambar saat ini:</small><br>
                    <img src="../<?= htmlspecialchars($product['image']); ?>" alt="Gambar Produk" style="max-width: 200px; height: auto;">
                <?php endif; ?>
            </div>
            <button type="submit" class="btn btn-primary">Perbarui Produk</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>