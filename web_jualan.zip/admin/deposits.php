<?php
session_start();
include '../includes/koneksi.php';

// Cek jika pengguna belum login atau bukan admin, arahkan ke halaman login
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Ambil semua data deposit dan gabungkan dengan data pengguna untuk menampilkan username
$sql = "SELECT d.*, u.username 
        FROM deposits d
        JOIN users u ON d.user_id = u.id
        ORDER BY d.created_at DESC";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Deposit - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Manajemen Deposit</h1>
        <p><a href="index.php" class="btn btn-secondary">Kembali ke Dashboard</a></p>
        
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success mt-3" role="alert"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger mt-3" role="alert"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        
        <div class="table-responsive">
            <table class="table table-striped table-hover mt-4">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Pengguna</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['id']); ?></td>
                                <td><?= htmlspecialchars($row['username']); ?></td>
                                <td>Rp<?= number_format($row['amount'], 0, ',', '.'); ?></td>
                                <td>
                                    <?php
                                        if ($row['status'] == 'pending') {
                                            echo '<span class="badge bg-warning text-dark">Pending</span>';
                                        } elseif ($row['status'] == 'approved') {
                                            echo '<span class="badge bg-success">Disetujui</span>';
                                        } else {
                                            echo '<span class="badge bg-danger">Ditolak</span>';
                                        }
                                    ?>
                                </td>
                                <td><?= date('d-m-Y H:i', strtotime($row['created_at'])); ?></td>
                                <td>
                                    <?php if ($row['status'] == 'pending'): ?>
                                        <a href="approve_deposit.php?id=<?= $row['id']; ?>" class="btn btn-success btn-sm me-2">Setujui</a>
                                        <a href="reject_deposit.php?id=<?= $row['id']; ?>" class="btn btn-danger btn-sm">Tolak</a>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">Tidak ada permintaan deposit.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>