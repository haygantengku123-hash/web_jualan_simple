<?php
// Mencegah akses langsung ke direktori ini
?>