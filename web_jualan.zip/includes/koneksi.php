<?php
//Buat belajar di kembangkan lagi yak
//thanks udah mampir jangan lupa follow Instagram ku @galuh_prdn12
$servername = "127.0.0.1"; // Ubah localhost menjadi IP 127.0.0.1
$username = "root"; //username database ente
$password = "root"; //password database ente
$dbname = "kingspe1_pfcsmmppob"; //nama database ente

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>