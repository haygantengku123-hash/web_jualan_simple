<?php
// Ganti dengan kunci rahasia yang panjang dan sulit ditebak
define('SECRET_KEY', '12345');

// Hanya izinkan akses dari command line atau dengan kunci rahasia yang benar
if (php_sapi_name() !== 'cli' && (!isset($_GET['key']) || $_GET['key'] !== SECRET_KEY)) {
    die("Akses tidak diizinkan.");
}

// Sertakan file koneksi database
require __DIR__ . '/../includes/koneksi.php';

echo "Memulai proses persetujuan deposit...\n";

// Ambil semua deposit yang statusnya 'pending'
$sql = "SELECT id, user_id, amount FROM deposits 
        WHERE status = 'pending'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo $result->num_rows . " deposit pending ditemukan. Memulai persetujuan...\n";
    
    while ($deposit = $result->fetch_assoc()) {
        $conn->begin_transaction();
        try {
            // 1. Tambahkan saldo ke akun pengguna
            $sql_update_user = "UPDATE users SET balance = balance + ? WHERE id = ?";
            $stmt_update_user = $conn->prepare($sql_update_user);
            $stmt_update_user->bind_param("di", $deposit['amount'], $deposit['user_id']);
            $stmt_update_user->execute();
            
            // 2. Perbarui status deposit menjadi 'approved'
            $sql_update_deposit = "UPDATE deposits SET status = 'approved' WHERE id = ?";
            $stmt_update_deposit = $conn->prepare($sql_update_deposit);
            $stmt_update_deposit->bind_param("i", $deposit['id']);
            $stmt_update_deposit->execute();
            
            $conn->commit();
            echo "Deposit #" . $deposit['id'] . " berhasil disetujui.\n";
            
        } catch (Exception $e) {
            $conn->rollback();
            echo "Error pada deposit #" . $deposit['id'] . ": " . $e->getMessage() . "\n";
        }
    }
    echo "Proses selesai.\n";
} else {
    echo "Tidak ada deposit pending yang perlu diproses.\n";
}

$conn->close();