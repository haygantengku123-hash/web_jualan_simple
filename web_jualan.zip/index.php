<?php
session_start();
include 'includes/koneksi.php';

// Ambil data saldo pengguna jika dia sudah login
$user_balance = null;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $sql_balance = "SELECT balance FROM users WHERE id = ?";
    $stmt_balance = $conn->prepare($sql_balance);
    $stmt_balance->bind_param("i", $user_id);
    $stmt_balance->execute();
    $result_balance = $stmt_balance->get_result();
    $user_data = $result_balance->fetch_assoc();
    $user_balance = $user_data['balance'];
}

// Ambil semua produk dari database
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Jualan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">Web Jualan</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item">
                            <span class="nav-link text-white">
                                Selamat datang, <?= $_SESSION['user_role']; ?>!
                            </span>
                        </li>
                        <?php if ($_SESSION['user_role'] === 'customer'): ?>
                            <li class="nav-item">
                                <span class="nav-link text-white">
                                    Saldo: Rp<?= number_format($user_balance, 0, ',', '.'); ?>
                                </span>
                            </li>
                            <li class="nav-item">
                                <a class="btn btn-outline-light ms-2" href="deposit.php">Deposit Saldo</a>
                            </li>
                            <li class="nav-item">
                                <a class="btn btn-outline-light ms-2" href="riwayat_transaksi.php">Riwayat Transaksi</a>
                           </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="btn btn-outline-light ms-2" href="admin/index.php">Dashboard Admin</a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="btn btn-danger ms-2" href="logout.php">Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="btn btn-outline-light" href="login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-light ms-2" href="register.php">Daftar</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container my-5">
        <h1 class="mb-4">Produk Terbaru</h1>
        
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success" role="alert"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger" role="alert"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <div class="row row-cols-1 row-cols-md-3 g-4">
            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <div class="col">
                        <div class="card h-100 product-card">
                            <?php if ($row['image']): ?>
                                <img src="<?= htmlspecialchars($row['image']); ?>" class="card-img-top" alt="<?= htmlspecialchars($row['name']); ?>">
                            <?php else: ?>
                                <img src="https://via.placeholder.com/400x200.png?text=No+Image" class="card-img-top" alt="No Image Available">
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($row['name']); ?></h5>
                                <p class="card-text text-muted"><?= htmlspecialchars($row['description']); ?></p>
                                <p class="card-text">
                                    <strong>Harga: Rp<?= number_format($row['price'], 0, ',', '.'); ?></strong>
                                    <br>
                                    <small class="text-secondary">Stok: <?= $row['stock']; ?></small>
                                </p>
                                <?php if (isset($_SESSION['user_id']) && $_SESSION['user_role'] === 'customer'): ?>
                                    <a href="#" class="btn btn-primary"
                                       data-bs-toggle="modal"
                                       data-bs-target="#buyModal"
                                       data-product-id="<?= $row['id']; ?>"
                                       data-product-name="<?= htmlspecialchars($row['name']); ?>"
                                       data-product-price="<?= number_format($row['price'], 0, ',', '.'); ?>">
                                        Beli Sekarang
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col"><p>Belum ada produk yang tersedia.</p></div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="modal fade" id="buyModal" tabindex="-1" aria-labelledby="buyModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="buyModalLabel">Konfirmasi Pembelian</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p id="modal-text"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <a id="buy-button" href="#" class="btn btn-primary">Beli</a>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    
    <script>
        var buyModal = document.getElementById('buyModal');
        buyModal.addEventListener('show.bs.modal', function (event) {
            // Tombol yang memicu modal
            var button = event.relatedTarget;
            
            // Ambil data dari atribut data-*
            var productId = button.getAttribute('data-product-id');
            var productName = button.getAttribute('data-product-name');
            var productPrice = button.getAttribute('data-product-price');
            
            // Perbarui konten modal
            var modalText = buyModal.querySelector('#modal-text');
            modalText.textContent = 'Apakah Anda yakin ingin membeli ' + productName + ' seharga Rp' + productPrice + '?';
            
            // Perbarui link tombol "Beli" di dalam modal
            var buyButton = buyModal.querySelector('#buy-button');
            buyButton.href = 'buy.php?id=' + productId;
        });
    </script>
</body>
</html>