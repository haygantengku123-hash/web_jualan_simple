<?php
session_start();
include 'includes/koneksi.php';

// Menampilkan error database (hanya untuk debugging)
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Cek jika pengguna belum login, arahkan ke halaman login
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'customer') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$result = null; // Inisialisasi variabel result

// Query untuk mengambil riwayat transaksi pembelian (dari tabel transactions)
// serta riwayat deposit (dari tabel deposits)
$sql = "
    (SELECT 
        'Pembelian' AS jenis_transaksi,
        p.name AS deskripsi,
        t.amount AS jumlah,
        t.created_at AS tanggal
    FROM transactions t
    JOIN products p ON t.product_id = p.id
    WHERE t.user_id = ?)
    UNION ALL
    (SELECT 
        'Deposit' AS jenis_transaksi,
        'Deposit Saldo' AS deskripsi,
        d.amount AS jumlah,
        d.created_at AS tanggal
    FROM deposits d
    WHERE d.user_id = ? AND d.status = 'approved')
    ORDER BY tanggal DESC
";

$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Gagal mempersiapkan query: " . $conn->error);
}
$stmt->bind_param("ii", $user_id, $user_id);

if (!$stmt->execute()) {
    die("Gagal mengeksekusi query: " . $stmt->error);
}

$result = $stmt->get_result();

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Transaksi - Web Jualan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">Web Jualan</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item">
                            <span class="nav-link text-white">
                                Selamat datang, <?= $_SESSION['user_role']; ?>!
                            </span>
                        </li>
                        <?php if ($_SESSION['user_role'] === 'customer'): ?>
                            <li class="nav-item">
                                <span class="nav-link text-white">
                                    Saldo: Rp<?= number_format($_SESSION['user_balance'], 0, ',', '.'); ?>
                                </span>
                            </li>
                            <li class="nav-item">
                                <a class="btn btn-outline-light ms-2" href="deposit.php">Deposit Saldo</a>
                            </li>
                            <li class="nav-item">
                                <a class="btn btn-outline-light ms-2" href="riwayat_transaksi.php">Riwayat Transaksi</a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="btn btn-outline-light ms-2" href="admin/index.php">Dashboard Admin</a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="btn btn-danger ms-2" href="logout.php">Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="btn btn-outline-light" href="login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-light ms-2" href="register.php">Daftar</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container my-5">
        <h1 class="mb-4">Riwayat Transaksi</h1>
        <p><a href="index.php" class="btn btn-outline-secondary">Kembali ke Beranda</a></p>
        <hr>
        
        <?php if ($result && $result->num_rows > 0): ?>
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Jenis Transaksi</th>
                        <th>Deskripsi</th>
                        <th>Jumlah</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['jenis_transaksi']); ?></td>
                            <td><?= htmlspecialchars($row['deskripsi']); ?></td>
                            <td>Rp<?= number_format($row['jumlah'], 0, ',', '.'); ?></td>
                            <td><?= date('d-m-Y H:i', strtotime($row['tanggal'])); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
            <div class="alert alert-info" role="alert">
                Belum ada riwayat transaksi.
            </div>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>