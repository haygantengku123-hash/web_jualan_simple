<?php
session_start();
include 'includes/koneksi.php';

// Cek hak akses customer
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'customer') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $amount = $_POST['amount'];
    
    // Validasi input
    if ($amount <= 0 || !is_numeric($amount)) {
        $error = "Jumlah deposit harus angka positif.";
    } else {
        // Masukkan permintaan deposit ke database dengan status 'pending'
        $sql = "INSERT INTO deposits (user_id, amount, status) VALUES (?, ?, 'pending')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("id", $user_id, $amount);

        if ($stmt->execute()) {
            $message = "Permintaan deposit sejumlah Rp" . number_format($amount, 0, ',', '.') . " berhasil diajukan. Menunggu persetujuan admin.";
        } else {
            $error = "Gagal mengajukan deposit: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deposit Saldo - Web Jualan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container my-5">
        <h1>Deposit Saldo</h1>
        <p><a href="index.php" class="btn btn-outline-secondary">Kembali ke Beranda</a></p>
        <hr>

        <?php if ($message): ?>
            <div class="alert alert-success" role="alert"><?= $message; ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert"><?= $error; ?></div>
        <?php endif; ?>

        <form action="deposit.php" method="post">
            <div class="mb-3">
                <label for="amount" class="form-label">Jumlah Deposit</label>
                <input type="number" step="1000" class="form-control" id="amount" name="amount" required>
                <div class="form-text">Masukkan jumlah deposit yang Anda inginkan (contoh: 50000).</div>
            </div>
            <button type="submit" class="btn btn-primary">Ajukan Deposit</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>