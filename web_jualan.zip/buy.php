<?php
session_start();
include 'includes/koneksi.php';

// Cek hak akses customer
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'customer') {
    $_SESSION['error'] = "Anda harus login untuk melakukan pembelian.";
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    $_SESSION['error'] = "ID produk tidak ditemukan.";
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$product_id = $_GET['id'];

// Mulai transaksi database
$conn->begin_transaction();

try {
    // 1. Ambil data produk
    $sql_product = "SELECT name, price, stock FROM products WHERE id = ?";
    $stmt_product = $conn->prepare($sql_product);
    $stmt_product->bind_param("i", $product_id);
    $stmt_product->execute();
    $result_product = $stmt_product->get_result();

    if ($result_product->num_rows === 0) {
        throw new Exception("Produk tidak ditemukan.");
    }

    $product = $result_product->fetch_assoc();
    $product_price = $product['price'];
    $product_stock = $product['stock'];

    // 2. Cek stok produk
    if ($product_stock <= 0) {
        throw new Exception("Maaf, stok produk habis.");
    }

    // 3. Ambil data saldo pengguna
    $sql_user = "SELECT balance FROM users WHERE id = ?";
    $stmt_user = $conn->prepare($sql_user);
    $stmt_user->bind_param("i", $user_id);
    $stmt_user->execute();
    $result_user = $stmt_user->get_result();
    $user = $result_user->fetch_assoc();
    $user_balance = $user['balance'];

    // 4. Cek saldo pengguna
    if ($user_balance < $product_price) {
        throw new Exception("Saldo Anda tidak mencukupi untuk membeli produk ini.");
    }

    // 5. Kurangi saldo pengguna
    $new_balance = $user_balance - $product_price;
    $sql_update_user = "UPDATE users SET balance = ? WHERE id = ?";
    $stmt_update_user = $conn->prepare($sql_update_user);
    $stmt_update_user->bind_param("di", $new_balance, $user_id);
    $stmt_update_user->execute();
    $_SESSION['user_balance'] = $new_balance;

    // 6. Kurangi stok produk
    $new_stock = $product_stock - 1;
    $sql_update_product = "UPDATE products SET stock = ? WHERE id = ?";
    $stmt_update_product = $conn->prepare($sql_update_product);
    $stmt_update_product->bind_param("ii", $new_stock, $product_id);
    $stmt_update_product->execute();
    
    // 7. Catat transaksi pembelian
    $sql_transaction = "INSERT INTO transactions (user_id, product_id, amount) VALUES (?, ?, ?)";
    $stmt_transaction = $conn->prepare($sql_transaction);
    $stmt_transaction->bind_param("iid", $user_id, $product_id, $product_price);
    $stmt_transaction->execute();

    // Jika semua berhasil, commit transaksi
    $conn->commit();
    $_SESSION['message'] = "Pembelian " . htmlspecialchars($product['name']) . " berhasil!";
    header("Location: index.php");
    exit();

} catch (Exception $e) {
    // Jika ada yang gagal, batalkan transaksi
    $conn->rollback();
    $_SESSION['error'] = $e->getMessage();
    header("Location: index.php");
    exit();
}

// Redirect jika ada kesalahan yang tidak tertangkap
$_SESSION['error'] = "Terjadi kesalahan yang tidak diketahui.";
header("Location: index.php");
exit();
?>